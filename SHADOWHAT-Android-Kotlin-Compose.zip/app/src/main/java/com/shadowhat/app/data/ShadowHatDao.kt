package com.shadowhat.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShadowHatDao {
    // Ads (Anuncios)
    @Query("SELECT * FROM ads ORDER BY updatedAt DESC")
    fun getAllAds(): Flow<List<AdEntity>>

    @Query("SELECT * FROM ads ORDER BY updatedAt DESC")
    suspend fun getAllAdsList(): List<AdEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAd(ad: AdEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAds(ads: List<AdEntity>)

    @Update
    suspend fun updateAd(ad: AdEntity)

    @Delete
    suspend fun deleteAd(ad: AdEntity)

    // Groups & Destinations (Grupos y Destinatarios)
    @Query("SELECT * FROM whatsapp_groups ORDER BY updatedAt DESC")
    fun getAllGroups(): Flow<List<GroupEntity>>

    @Query("SELECT * FROM whatsapp_groups ORDER BY updatedAt DESC")
    suspend fun getAllGroupsList(): List<GroupEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGroup(group: GroupEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGroups(groups: List<GroupEntity>)

    @Update
    suspend fun updateGroup(group: GroupEntity)

    @Delete
    suspend fun deleteGroup(group: GroupEntity)

    @Query("DELETE FROM whatsapp_groups WHERE id IN (:ids)")
    suspend fun deleteGroupsByIds(ids: List<String>)

    // Campaigns (Campañas)
    @Query("SELECT * FROM campaigns ORDER BY createdAt DESC")
    fun getAllCampaigns(): Flow<List<CampaignEntity>>

    @Query("SELECT * FROM campaigns ORDER BY createdAt DESC")
    suspend fun getAllCampaignsList(): List<CampaignEntity>

    @Query("SELECT * FROM campaigns WHERE status = 'en_curso' ORDER BY createdAt DESC")
    suspend fun getActiveRunningCampaigns(): List<CampaignEntity>

    @Query("SELECT * FROM campaigns WHERE id = :id LIMIT 1")
    suspend fun getCampaignById(id: String): CampaignEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaign(campaign: CampaignEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaigns(campaigns: List<CampaignEntity>)

    @Update
    suspend fun updateCampaign(campaign: CampaignEntity)

    @Query("UPDATE campaigns SET status = 'pausado' WHERE status = 'en_curso'")
    suspend fun pauseAllRunningCampaigns()

    @Query("UPDATE campaigns SET status = 'cancelado', completedAt = :now WHERE status IN ('en_curso', 'pausado', 'preparado')")
    suspend fun cancelAllActiveCampaigns(now: Long = System.currentTimeMillis())

    // Task Queue (Cola de tareas con prevención de duplicados por idempotencyKey)
    @Query("SELECT * FROM task_queue ORDER BY rowid ASC")
    fun getAllQueueItems(): Flow<List<TaskQueueEntity>>

    @Query("SELECT * FROM task_queue ORDER BY rowid ASC")
    suspend fun getAllQueueItemsList(): List<TaskQueueEntity>

    @Query("SELECT * FROM task_queue WHERE campaignId = :campaignId")
    suspend fun getTasksForCampaignList(campaignId: String): List<TaskQueueEntity>

    @Query("SELECT * FROM task_queue WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getTaskByIdempotencyKey(key: String): TaskQueueEntity?

    @Query("SELECT * FROM task_queue WHERE status IN ('preparado', 'en_cola_servidor', 'reintento_programado', 'abierto_en_whatsapp', 'pending') ORDER BY rowid ASC")
    suspend fun getPendingTasks(): List<TaskQueueEntity>

    @Query("SELECT * FROM task_queue WHERE status = 'preparado' ORDER BY rowid ASC LIMIT 1")
    suspend fun getNextPreparedAssistedTask(): TaskQueueEntity?

    /**
     * Recuperación segura tras reinicio del teléfono o cierre del proceso:
     * Si una tarea quedó en estado transitorio 'enviando' sin confirmación verificable (wamid IS NULL),
     * la devuelve a 'reintento_programado' para que el servidor o el worker la verifique sin duplicar
     * aquellas que ya tienen wamid o están en 'abierto_en_whatsapp'.
     */
    @Query("UPDATE task_queue SET status = 'reintento_programado', observations = 'Recuperado tras interrupción del sistema (pendiente de verificación sin duplicar)' WHERE status = 'enviando' AND wamid IS NULL")
    suspend fun recoverInterruptedSendingTasks(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertQueueItemsIgnoreDuplicates(items: List<TaskQueueEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQueueItems(items: List<TaskQueueEntity>)

    @Update
    suspend fun updateQueueItem(item: TaskQueueEntity)

    @Query("UPDATE task_queue SET status = 'cancelado', observations = 'Campaña detenida inmediatamente por el usuario' WHERE campaignId = :campaignId AND status IN ('preparado', 'en_cola_servidor', 'reintento_programado')")
    suspend fun cancelPendingTasksForCampaign(campaignId: String)

    @Query("UPDATE task_queue SET status = 'cancelado', observations = 'Detenido desde notificación de servicio' WHERE status IN ('preparado', 'en_cola_servidor', 'reintento_programado')")
    suspend fun cancelAllPendingTasks()

    @Query("DELETE FROM task_queue WHERE status IN ('confirmado_manualmente', 'confirmado_cloud_api', 'entregado_webhook', 'leido_webhook', 'omitido_baja', 'cancelado', 'sent_verified')")
    suspend fun clearCompletedQueueItems()

    @Query("DELETE FROM task_queue")
    suspend fun clearAllQueueItems()

    // History (Historial verificable)
    @Query("SELECT * FROM campaign_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM campaign_history ORDER BY timestamp DESC")
    suspend fun getAllHistoryList(): List<HistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: HistoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistoryList(history: List<HistoryEntity>)

    @Update
    suspend fun updateHistory(history: HistoryEntity)

    @Query("DELETE FROM campaign_history")
    suspend fun clearHistory()
}
