package com.shadowhat.app.dispatcher

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast

object WhatsAppDispatcher {

    const val PACKAGE_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
    const val PACKAGE_WHATSAPP_STANDARD = "com.whatsapp"

    enum class AppAvailability {
        WHATSAPP_BUSINESS,
        WHATSAPP_STANDARD,
        NONE
    }

    data class DispatchOutcome(
        val success: Boolean,
        val targetPackageUsed: String?,
        val mediaAttached: Boolean,
        val statusMessage: String
    )

    data class SystemBackgroundDiagnostics(
        val ignoringBatteryOptimizations: Boolean,
        val isBackgroundRestricted: Boolean,
        val isDeviceInDozeMode: Boolean,
        val manufacturer: String,
        val oemSpecificAdvice: String,
        val accessibilityPolicyNote: String
    )

    /**
     * Evalúa el estado real de restricciones de batería, modo Doze, App Standby y capa de fabricante (OEM).
     */
    fun inspectBackgroundAndPowerState(context: Context): SystemBackgroundDiagnostics {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager

        val ignoringBattery = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pm?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        } else {
            true
        }

        val backgroundRestricted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            am?.isBackgroundRestricted ?: false
        } else {
            false
        }

        val inDoze = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pm?.isDeviceIdleMode ?: false
        } else {
            false
        }

        val mfg = (Build.MANUFACTURER ?: "Android").trim()
        val oemAdvice = when (mfg.lowercase()) {
            "xiaomi", "redmi", "poco" ->
                "Xiaomi (MIUI/HyperOS): Activa 'Inicio automático en segundo plano' y selecciona 'Sin restricciones' en Ahorro de batería de MIUI."
            "samsung" ->
                "Samsung (OneUI): En Cuidado del dispositivo > Batería > Límites de uso en segundo plano, añade SHADOWHAT a 'Aplicaciones que nunca se suspenden'."
            "huawei", "honor" ->
                "Huawei/Honor: En Ajustes > Batería > Inicio de aplicaciones, desactiva la gestión automática para SHADOWHAT y permite ejecución en segundo plano."
            "oppo", "realme", "oneplus" ->
                "ColorOS / OxygenOS: En Información de la aplicación > Uso de batería, activa 'Permitir actividad en segundo plano' e 'Inicio automático'."
            "vivo", "iqoo" ->
                "Vivo (FuntouchOS): En Batería > Consumo de energía en segundo plano, habilita 'Alto consumo de energía en segundo plano' para SHADOWHAT."
            else ->
                "Android Estándar: Configura SHADOWHAT como 'Sin restricciones' en Uso de batería para evitar que Doze detenga el servicio activo."
        }

        val accessibilityNote =
            "Política de Accesibilidad: SHADOWHAT NO utiliza AccessibilityService para simular toques ni leer la pantalla de WhatsApp, ya que infringe las políticas de Google Play y los Términos de WhatsApp (riesgo de bloqueo de cuenta) y falla siempre con la pantalla bloqueada."

        return SystemBackgroundDiagnostics(
            ignoringBatteryOptimizations = ignoringBattery,
            isBackgroundRestricted = backgroundRestricted,
            isDeviceInDozeMode = inDoze,
            manufacturer = mfg,
            oemSpecificAdvice = oemAdvice,
            accessibilityPolicyNote = accessibilityNote
        )
    }

    /**
     * Checks which WhatsApp variant is installed on the user's Android phone.
     */
    fun checkInstalledWhatsApp(context: Context): AppAvailability {
        val pm = context.packageManager
        if (isPackageInstalled(pm, PACKAGE_WHATSAPP_BUSINESS)) {
            return AppAvailability.WHATSAPP_BUSINESS
        }
        if (isPackageInstalled(pm, PACKAGE_WHATSAPP_STANDARD)) {
            return AppAvailability.WHATSAPP_STANDARD
        }
        return AppAvailability.NONE
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Takes a persistable URI permission when the user picks a photo or video via OpenDocument.
     */
    fun persistMediaUriPermission(context: Context, uri: Uri) {
        try {
            val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, takeFlags)
        } catch (_: SecurityException) {
            // Some providers do not support persistable permissions; transient grant still works
        }
    }

    /**
     * Verifies if a media URI can actually be read before attaching to an Intent.
     */
    fun isMediaUriAccessible(context: Context, uriString: String?): Boolean {
        if (uriString.isNullOrBlank()) return false
        return try {
            val uri = Uri.parse(uriString)
            context.contentResolver.openInputStream(uri)?.use { }
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Opens WhatsApp Business or standard WhatsApp directly if installed.
     */
    fun openWhatsAppBusinessApp(context: Context): Boolean {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(PACKAGE_WHATSAPP_BUSINESS)
            ?: pm.getLaunchIntentForPackage(PACKAGE_WHATSAPP_STANDARD)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else {
            Toast.makeText(
                context,
                "Ni WhatsApp Business ni WhatsApp estándar están instalados en este teléfono.",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }

    /**
     * Prepares and opens WhatsApp Business (or standard WhatsApp) with text, price, and optional photo/video URI.
     * Note: WhatsApp does not provide a public API to pre-select a private group ID automatically via Intent.ACTION_SEND.
     * Therefore, this method prepares the full content and opens WhatsApp's group selector so the user manually selects
     * the target group, reviews the attachment/caption, sends it, and then confirms the real result back in SHADOWHAT.
     */
    fun dispatchAdToWhatsApp(
        context: Context,
        formattedMessage: String,
        targetGroupHint: String,
        mediaUriString: String? = null,
        mediaMimeType: String? = null,
        preferBusiness: Boolean = true
    ): DispatchOutcome {
        // 1. Copy formatted ad text to clipboard as backup
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText("SHADOWHAT ($targetGroupHint)", formattedMessage))

        // 2. Check if WhatsApp Business or standard WhatsApp is installed
        val availability = checkInstalledWhatsApp(context)
        if (availability == AppAvailability.NONE) {
            Toast.makeText(
                context,
                "Error: WhatsApp Business / WhatsApp no está instalado en este dispositivo.",
                Toast.LENGTH_LONG
            ).show()
            return DispatchOutcome(
                success = false,
                targetPackageUsed = null,
                mediaAttached = false,
                statusMessage = "WhatsApp no está instalado en el dispositivo"
            )
        }

        val targetPackage = if (preferBusiness && availability == AppAvailability.WHATSAPP_BUSINESS) {
            PACKAGE_WHATSAPP_BUSINESS
        } else {
            PACKAGE_WHATSAPP_STANDARD
        }

        val hasAccessibleMedia = isMediaUriAccessible(context, mediaUriString)

        return try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                `package` = targetPackage
                putExtra(Intent.EXTRA_TEXT, formattedMessage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                if (hasAccessibleMedia && !mediaUriString.isNullOrBlank()) {
                    val uri = Uri.parse(mediaUriString)
                    val resolvedMime = mediaMimeType
                        ?: context.contentResolver.getType(uri)
                        ?: if (mediaUriString.contains("video", ignoreCase = true)) "video/*" else "image/*"
                    type = resolvedMime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    clipData = ClipData.newRawUri("SHADOWHAT Media", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } else {
                    type = "text/plain"
                }
            }

            context.startActivity(sendIntent)
            Toast.makeText(
                context,
                "Selecciona el grupo '$targetGroupHint' en WhatsApp y confirma al volver",
                Toast.LENGTH_LONG
            ).show()

            DispatchOutcome(
                success = true,
                targetPackageUsed = targetPackage,
                mediaAttached = hasAccessibleMedia,
                statusMessage = if (hasAccessibleMedia) {
                    "Abierto en WhatsApp con archivo multimedia y texto preparado"
                } else {
                    "Abierto en WhatsApp con texto preparado"
                }
            )
        } catch (e: Exception) {
            Toast.makeText(context, "Error al abrir WhatsApp: ${e.message}", Toast.LENGTH_LONG).show()
            DispatchOutcome(
                success = false,
                targetPackageUsed = targetPackage,
                mediaAttached = false,
                statusMessage = "Error al iniciar Intent: ${e.message}"
            )
        }
    }

    /**
     * Legacy helper for text-only dispatch compatibility.
     */
    fun dispatchMessage(
        context: Context,
        message: String,
        targetGroupHint: String,
        preferBusiness: Boolean = true
    ): Boolean {
        return dispatchAdToWhatsApp(
            context = context,
            formattedMessage = message,
            targetGroupHint = targetGroupHint,
            mediaUriString = null,
            mediaMimeType = null,
            preferBusiness = preferBusiness
        ).success
    }

    fun openBatteryOptimizationSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }

    fun openNotificationSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }
}
