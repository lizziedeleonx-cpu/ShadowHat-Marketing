package com.shadowhat.app.dispatcher

import android.content.Context
import com.shadowhat.app.data.CampaignEntity
import com.shadowhat.app.data.GroupEntity
import com.shadowhat.app.data.HistoryEntity
import com.shadowhat.app.data.ShadowHatDao
import com.shadowhat.app.data.TaskQueueEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Cliente nativo Android para comunicarse con el Backend Cloud de SHADOWHAT (`server.ts`).
 *
 * SEGURIDAD:
 * - El APK NUNCA almacena `WHATSAPP_CLOUD_API_TOKEN` ni credenciales de Meta.
 * - Solo almacena la URL del servidor propio y el token de cliente (`SHADOWHAT_API_KEY`)
 *   en SharedPreferences privadas de la aplicación.
 */
object CloudCampaignClient {
    private const val PREFS_NAME = "shadowhat_cloud_prefs"
    private const val KEY_SERVER_URL = "server_url"
    private const val KEY_CLIENT_API_KEY = "client_api_key"
    private const val KEY_DEFAULT_TEMPLATE = "default_template_name"

    data class CloudDiagnostics(
        val reachable: Boolean,
        val credentialsConfigured: Boolean,
        val isObaAccount: Boolean,
        val rateLimitMps: Int,
        val summaryMessage: String
    )

    fun getServerUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_SERVER_URL, "") ?: ""
    }

    fun getClientApiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_CLIENT_API_KEY, "") ?: ""
    }

    fun getDefaultTemplateName(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_DEFAULT_TEMPLATE, "oferta_producto_shadowhat") ?: "oferta_producto_shadowhat"
    }

    fun saveCloudConfig(context: Context, serverUrl: String, clientApiKey: String, defaultTemplate: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_SERVER_URL, serverUrl.trim().removeSuffix("/"))
            .putString(KEY_CLIENT_API_KEY, clientApiKey.trim())
            .putString(KEY_DEFAULT_TEMPLATE, defaultTemplate.trim())
            .apply()
    }

    suspend fun checkDiagnostics(context: Context): CloudDiagnostics = withContext(Dispatchers.IO) {
        val baseUrl = getServerUrl(context)
        if (baseUrl.isBlank()) {
            return@withContext CloudDiagnostics(
                reachable = false,
                credentialsConfigured = false,
                isObaAccount = false,
                rateLimitMps = 10,
                summaryMessage = "URL del servidor no configurada en Ajustes. Operando en Modo Asistido Android."
            )
        }

        try {
            val conn = openConnection("$baseUrl/api/whatsapp/diagnostics", "GET", getClientApiKey(context))
            val code = conn.responseCode
            val body = readBody(conn)
            if (code in 200..299) {
                val json = JSONObject(body)
                val credsOk = json.optBoolean("credentialsConfigured", false)
                val mps = json.optInt("rateLimitMps", 10)
                val liveInfo = json.optJSONObject("liveAccountInfo")
                val isOba = liveInfo?.optBoolean("is_official_business_account", false) ?: false

                val msg = when {
                    credsOk && isOba -> "Servidor Online: Cloud API + Cuenta Oficial OBA verificada ($mps MPS)"
                    credsOk -> "Servidor Online: Cloud API activa para Plantillas 1:1 ($mps MPS). Grupos API requiere OBA."
                    else -> "Servidor Online, pero faltan WHATSAPP_CLOUD_API_TOKEN / PHONE_NUMBER_ID en el servidor."
                }
                CloudDiagnostics(
                    reachable = true,
                    credentialsConfigured = credsOk,
                    isObaAccount = isOba,
                    rateLimitMps = mps,
                    summaryMessage = msg
                )
            } else {
                CloudDiagnostics(
                    reachable = false,
                    credentialsConfigured = false,
                    isObaAccount = false,
                    rateLimitMps = 10,
                    summaryMessage = "Servidor respondió HTTP $code: verifica SHADOWHAT_API_KEY"
                )
            }
        } catch (e: Exception) {
            CloudDiagnostics(
                reachable = false,
                credentialsConfigured = false,
                isObaAccount = false,
                rateLimitMps = 10,
                summaryMessage = "No se pudo conectar al servidor: ${e.message}"
            )
        }
    }

    /**
     * Envía una campaña al servidor Cloud para que se ejecute en segundo plano real
     * incluso si la pantalla del teléfono se bloquea, la app se cierra o el teléfono se apaga.
     */
    suspend fun submitCampaignToServer(
        context: Context,
        campaign: CampaignEntity,
        targets: List<GroupEntity>,
        autoStart: Boolean = true
    ): Result<String> = withContext(Dispatchers.IO) {
        val baseUrl = getServerUrl(context)
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Configura primero la URL del Backend en Ajustes."))
        }

        try {
            val destinationsArr = JSONArray()
            targets.forEach { grp ->
                val obj = JSONObject().apply {
                    put("id", grp.id)
                    put("name", grp.name)
                    put("destinationType", grp.destinationType)
                    put("recipientAddress", grp.recipientAddress ?: "")
                    put("category", grp.category)
                    put("optedOut", grp.optedOut)
                }
                destinationsArr.put(obj)
            }

            val payload = JSONObject().apply {
                put("id", campaign.id)
                put("title", campaign.title)
                put("category", campaign.category)
                put("adId", campaign.adId ?: "")
                put("adProductName", campaign.adProductName ?: campaign.title)
                put("price", campaign.price)
                put("message", campaign.message)
                put("mediaUrl", campaign.mediaUri ?: "")
                put("mediaMimeType", campaign.mediaMimeType ?: "")
                put("templateName", campaign.templateName ?: getDefaultTemplateName(context))
                put("executionMode", campaign.executionMode)
                put("rateLimitMps", campaign.rateLimitMps)
                put("autoStart", autoStart)
                put("destinations", destinationsArr)
            }

            val conn = openConnection("$baseUrl/api/campaigns", "POST", getClientApiKey(context))
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload.toString())
            }

            val code = conn.responseCode
            val responseText = readBody(conn)
            if (code in 200..299) {
                Result.success("Campaña sincronizada con el servidor Cloud")
            } else {
                Result.failure(RuntimeException("Error HTTP $code: $responseText"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Ejecuta una acción de control en el servidor: start, pause, resume o cancel.
     */
    suspend fun controlServerCampaign(
        context: Context,
        campaignId: String,
        action: String // "start" | "pause" | "resume" | "cancel"
    ): Boolean = withContext(Dispatchers.IO) {
        val baseUrl = getServerUrl(context)
        if (baseUrl.isBlank()) return@withContext false
        return@withContext try {
            val conn = openConnection("$baseUrl/api/campaigns/$campaignId/$action", "POST", getClientApiKey(context))
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write("{}") }
            conn.responseCode in 200..299
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Sincroniza el estado real de las tareas del servidor (incluyendo WAMID, errores o bajas)
     * con la base de datos local Room en Android.
     */
    suspend fun syncServerStateToRoom(context: Context, dao: ShadowHatDao): Int = withContext(Dispatchers.IO) {
        val baseUrl = getServerUrl(context)
        if (baseUrl.isBlank()) return@withContext 0

        try {
            val conn = openConnection("$baseUrl/api/state", "GET", getClientApiKey(context))
            if (conn.responseCode !in 200..299) return@withContext 0
            val json = JSONObject(readBody(conn))
            val queueArr = json.optJSONArray("queue") ?: return@withContext 0

            var updatedCount = 0
            for (i in 0 until queueArr.length()) {
                val item = queueArr.getJSONObject(i)
                val idempotencyKey = item.optString("idempotencyKey", "")
                if (idempotencyKey.isBlank()) continue

                val localTask = dao.getTaskByIdempotencyKey(idempotencyKey)
                val serverStatus = item.optString("status", "preparado")
                val serverWamid = item.optString("wamid", "").ifBlank { null }
                val serverObs = item.optString("observations", "").ifBlank { null }
                val serverErr = item.optString("errorMessage", "").ifBlank { null }
                val attempts = item.optInt("attempts", 0)

                if (localTask != null && (localTask.status != serverStatus || localTask.wamid != serverWamid)) {
                    val updated = localTask.copy(
                        status = serverStatus,
                        attempts = attempts,
                        wamid = serverWamid,
                        observations = serverObs,
                        errorMessage = serverErr,
                        verifiedAt = if (serverWamid != null) System.currentTimeMillis() else localTask.verifiedAt
                    )
                    dao.updateQueueItem(updated)
                    dao.insertHistory(
                        HistoryEntity(
                            id = UUID.randomUUID().toString(),
                            campaignId = localTask.campaignId,
                            campaignTitle = "Campaña: ${localTask.adProductName}",
                            category = localTask.category,
                            adId = localTask.adId,
                            adProductName = localTask.adProductName,
                            groupId = localTask.groupId,
                            groupName = localTask.groupName,
                            messageSnippet = localTask.message.take(80),
                            status = serverStatus,
                            wamid = serverWamid,
                            observations = serverObs ?: "Sincronizado desde servidor Cloud",
                            timestamp = System.currentTimeMillis(),
                            attempts = attempts,
                            method = "whatsapp_cloud_api"
                        )
                    )
                    updatedCount++
                }
            }
            updatedCount
        } catch (_: Exception) {
            0
        }
    }

    private fun openConnection(urlStr: String, method: String, apiKey: String): HttpURLConnection {
        val url = URL(urlStr)
        return (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
            if (apiKey.isNotBlank()) {
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            if (method == "POST") {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
    }

    private fun readBody(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        if (stream == null) return ""
        return BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
    }
}
