package com.shadowhat.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "ads")
data class AdEntity(
    @PrimaryKey
    val id: String,
    val productName: String,
    val description: String,
    val price: String,
    val photoUri: String? = null,
    val videoUri: String? = null,
    val mediaMimeType: String? = null,
    val status: String = "Activo", // Activo, Borrador, Inactivo
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "whatsapp_groups")
data class GroupEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val description: String? = null,
    val category: String,
    val isActive: Boolean = true,
    val destinationType: String = "GROUP_MANUAL", // GROUP_MANUAL, RECIPIENT_CLOUD_API, GROUP_CLOUD_API
    val recipientAddress: String? = null, // Número E.164 (+521...) o ID de grupo oficial Cloud API
    val optedOut: Boolean = false, // Respeto a solicitudes de baja (STOP / BAJA)
    val inviteLink: String? = null,
    val notes: String? = null,
    val contactCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "campaigns")
data class CampaignEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val category: String = "General",
    val adId: String? = null,
    val adProductName: String? = null,
    val message: String,
    val price: String = "",
    val mediaUri: String? = null,
    val mediaMimeType: String? = null,
    val targetGroupIdsJson: String,
    val status: String, // preparado, en_curso, pausado, completado, cancelado
    val executionMode: String = "ANDROID_ASSISTED", // CLOUD_API o ANDROID_ASSISTED
    val templateName: String? = null,
    val rateLimitMps: Int = 10, // Límite oficial de envíos por segundo
    val dispatchIntervalMs: Long = 1000L,
    val assistedMode: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

@Entity(
    tableName = "task_queue",
    indices = [Index(value = ["idempotencyKey"], unique = true)]
)
data class TaskQueueEntity(
    @PrimaryKey
    val id: String,
    val idempotencyKey: String = "", // "${campaignId}:${groupId}" — impide duplicados al reanudar
    val campaignId: String,
    val category: String = "General",
    val adId: String? = null,
    val adProductName: String = "",
    val groupId: String,
    val groupName: String,
    val destinationType: String = "GROUP_MANUAL",
    val recipientAddress: String? = null,
    val message: String,
    val price: String = "",
    val mediaUri: String? = null,
    val mediaMimeType: String? = null,
    val status: String, // preparado, en_cola_servidor, reintento_programado, abierto_en_whatsapp, confirmado_manualmente, confirmado_cloud_api, omitido_baja, cancelado, error
    val attempts: Int = 0,
    val maxAttempts: Int = 3,
    val nextRetryAt: Long? = null,
    val lastAttemptAt: Long? = null,
    val verifiedAt: Long? = null,
    val wamid: String? = null, // ID verificable oficial de WhatsApp Cloud API
    val isPermanentError: Boolean = false,
    val observations: String? = null,
    val errorMessage: String? = null
)

@Entity(tableName = "campaign_history")
data class HistoryEntity(
    @PrimaryKey
    val id: String,
    val campaignId: String,
    val campaignTitle: String,
    val category: String = "General",
    val adId: String? = null,
    val adProductName: String = "",
    val groupId: String,
    val groupName: String,
    val messageSnippet: String,
    val status: String, // preparado, abierto_en_whatsapp, confirmado_manualmente, confirmado_cloud_api, omitido_baja, cancelado, error
    val wamid: String? = null,
    val observations: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val attempts: Int = 1,
    val method: String = "whatsapp_business_intent"
)
