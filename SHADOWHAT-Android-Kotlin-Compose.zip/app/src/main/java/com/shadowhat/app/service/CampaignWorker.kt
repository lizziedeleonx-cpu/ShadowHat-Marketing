package com.shadowhat.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.shadowhat.app.MainActivity
import com.shadowhat.app.data.AppDatabase
import com.shadowhat.app.dispatcher.CloudCampaignClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Worker persistente administrado por Android WorkManager.
 *
 * RESPONSABILIDADES REALES:
 * 1. Sincronizar estados y confirmaciones (`wamid`) con el servidor Cloud autorizado (`CloudCampaignClient`).
 * 2. Recuperar de forma segura cualquier tarea que haya quedado en estado transitorio `enviando`
 *    tras un reinicio del dispositivo, modo Doze o cierre del proceso (`recoverInterruptedSendingTasks()`),
 *    sin volver a encolar tareas ya confirmadas o con `wamid` registrado.
 * 3. No asume ni promete que WorkManager pueda mantener abierta la interfaz de WhatsApp ni simular clics
 *    con la pantalla bloqueada.
 */
class CampaignWorker(
    private val appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val CHANNEL_ID = "shadowhat_campaign_channel"
        const val NOTIFICATION_ID = 101
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val database = AppDatabase.getDatabase(appContext)
        val dao = database.dao()
        val isBootRecovery = inputData.getBoolean("is_boot_recovery", false)

        createNotificationChannel()

        try {
            // 1. Primero reconciliar con el servidor Cloud por si la campaña avanzó con el teléfono apagado
            val syncedCount = CloudCampaignClient.syncServerStateToRoom(appContext, dao)

            // 2. Recuperar de forma segura tareas locales interrumpidas sin duplicar las ya confirmadas
            val recoveredCount = dao.recoverInterruptedSendingTasks()

            // 3. Consultar tareas pendientes tras la reconciliación
            val pendingTasks = dao.getPendingTasks()
            if (pendingTasks.isEmpty()) {
                if (syncedCount > 0 || isBootRecovery) {
                    showProgressNotification(
                        "SHADOWHAT — Cola al Día",
                        "Todas las tareas fueron verificadas ($syncedCount sincronizadas del servidor Cloud)."
                    )
                }
                return@withContext Result.success()
            }

            val cloudCount = pendingTasks.count {
                it.status == "en_cola_servidor" || it.status == "reintento_programado"
            }
            val assistedCount = pendingTasks.size - cloudCount

            val notificationTitle = if (isBootRecovery || recoveredCount > 0) {
                "SHADOWHAT — Campaña Recuperada tras Reinicio"
            } else {
                "SHADOWHAT — Progreso de Campaña"
            }

            val notificationText = when {
                cloudCount > 0 && assistedCount > 0 ->
                    "$cloudCount procesándose en servidor Cloud • $assistedCount para confirmar en WhatsApp"
                cloudCount > 0 ->
                    "$cloudCount envíos activos en el servidor Cloud (continúa aunque bloquees la pantalla)"
                else ->
                    "$assistedCount destinos listos para abrir y confirmar en WhatsApp Business"
            }

            showProgressNotification(notificationTitle, notificationText)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SHADOWHAT — Recuperación y Sincronización",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificaciones de recuperación segura de cola y sincronización Cloud"
            }
            val manager = appContext.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun showProgressNotification(title: String, content: String) {
        val openIntent = Intent(appContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            appContext,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        val builder = NotificationCompat.Builder(appContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)

        manager?.notify(NOTIFICATION_ID, builder.build())
    }
}
