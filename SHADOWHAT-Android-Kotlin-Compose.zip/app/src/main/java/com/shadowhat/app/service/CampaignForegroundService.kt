package com.shadowhat.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.shadowhat.app.MainActivity
import com.shadowhat.app.data.AppDatabase
import com.shadowhat.app.data.HistoryEntity
import com.shadowhat.app.dispatcher.CloudCampaignClient
import com.shadowhat.app.dispatcher.WhatsAppDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Servicio en primer plano (`ForegroundService` de tipo `dataSync`) con notificación visible.
 *
 * REGLAS DE ANDROID Y EXPERIENCIA ESTILO WHATSTOOL:
 * 1. Solo se inicia desde primer plano cuando el usuario pulsa "Iniciar" o "Reanudar" una campaña
 *    (cumpliendo estrictamente las restricciones de Android 12, 13 y 14 / API 34).
 * 2. Muestra una notificación persistente interactiva con:
 *    - Progreso verificable en tiempo real (Confirmados / Total / En cola).
 *    - Botón "Siguiente en WA": permite abrir el siguiente destino asistido en WhatsApp Business
 *      directamente desde la barra de notificaciones sin tener que regresar manualmente a SHADOWHAT.
 *    - Botón "Pausar": pausa inmediatamente la campaña local y en el servidor Cloud.
 *    - Botón "Detener": cancela las tareas pendientes y cierra el servicio en primer plano.
 * 3. Se detiene automáticamente (`stopForeground` + `stopSelf`) en cuanto no quedan tareas activas,
 *    evitando consumo innecesario de batería.
 */
class CampaignForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "shadowhat_fgs_campaign_channel"
        const val NOTIFICATION_ID = 202

        const val ACTION_START_OR_UPDATE = "com.shadowhat.app.action.START_OR_UPDATE"
        const val ACTION_DISPATCH_NEXT = "com.shadowhat.app.action.DISPATCH_NEXT"
        const val ACTION_PAUSE_CAMPAIGN = "com.shadowhat.app.action.PAUSE_CAMPAIGN"
        const val ACTION_STOP_CAMPAIGN = "com.shadowhat.app.action.STOP_CAMPAIGN"

        fun startOrUpdate(context: Context) {
            val intent = Intent(context, CampaignForegroundService::class.java).apply {
                action = ACTION_START_OR_UPDATE
            }
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Exception) {
                // Si Android restringe el inicio por estar en segundo plano profundo, WorkManager toma el relevo
            }
        }

        fun pause(context: Context) {
            val intent = Intent(context, CampaignForegroundService::class.java).apply {
                action = ACTION_PAUSE_CAMPAIGN
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {}
        }

        fun stop(context: Context) {
            val intent = Intent(context, CampaignForegroundService::class.java).apply {
                action = ACTION_STOP_CAMPAIGN
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {}
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitorJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_OR_UPDATE

        val initialNotification = buildCampaignNotification(
            title = "SHADOWHAT — Servicio de Campaña Activo",
            body = "Sincronizando cola persistente y destinos...",
            hasNextAssisted = false
        )
        promoteToForeground(initialNotification)

        when (action) {
            ACTION_DISPATCH_NEXT -> {
                serviceScope.launch {
                    dispatchNextAssistedTaskFromNotification()
                    refreshNotificationOrStop()
                }
            }
            ACTION_PAUSE_CAMPAIGN -> {
                serviceScope.launch {
                    val dao = AppDatabase.getDatabase(applicationContext).dao()
                    val running = dao.getActiveRunningCampaigns()
                    dao.pauseAllRunningCampaigns()
                    running.forEach { camp ->
                        if (camp.executionMode == "CLOUD_API") {
                            CloudCampaignClient.controlServerCampaign(applicationContext, camp.id, "pause")
                        }
                    }
                    stopForegroundSafely()
                }
            }
            ACTION_STOP_CAMPAIGN -> {
                serviceScope.launch {
                    val dao = AppDatabase.getDatabase(applicationContext).dao()
                    val running = dao.getActiveRunningCampaigns()
                    dao.cancelAllActiveCampaigns()
                    dao.cancelAllPendingTasks()
                    running.forEach { camp ->
                        if (camp.executionMode == "CLOUD_API") {
                            CloudCampaignClient.controlServerCampaign(applicationContext, camp.id, "cancel")
                        }
                    }
                    stopForegroundSafely()
                }
            }
            else -> {
                startMonitoringLoop()
            }
        }

        return START_STICKY
    }

    private fun startMonitoringLoop() {
        if (monitorJob?.isActive == true) return
        monitorJob = serviceScope.launch {
            val dao = AppDatabase.getDatabase(applicationContext).dao()
            while (isActive) {
                // Sincronizar con el servidor Cloud si está configurado
                CloudCampaignClient.syncServerStateToRoom(applicationContext, dao)

                val shouldContinue = refreshNotificationOrStop()
                if (!shouldContinue) {
                    break
                }
                delay(4000L)
            }
        }
    }

    /**
     * Avanza al siguiente destino preparado en Modo Asistido cuando el usuario pulsa
     * "Siguiente en WA" directamente desde la notificación interactiva.
     */
    private suspend fun dispatchNextAssistedTaskFromNotification() {
        val dao = AppDatabase.getDatabase(applicationContext).dao()
        val nextTask = dao.getNextPreparedAssistedTask() ?: return

        val outcome = WhatsAppDispatcher.dispatchAdToWhatsApp(
            context = applicationContext,
            formattedMessage = nextTask.message,
            targetGroupHint = nextTask.groupName,
            mediaUriString = nextTask.mediaUri,
            mediaMimeType = nextTask.mediaMimeType,
            preferBusiness = true
        )

        val now = System.currentTimeMillis()
        if (outcome.success) {
            val updated = nextTask.copy(
                status = "abierto_en_whatsapp",
                attempts = nextTask.attempts + 1,
                lastAttemptAt = now,
                observations = outcome.statusMessage
            )
            dao.updateQueueItem(updated)
            dao.insertHistory(
                HistoryEntity(
                    id = UUID.randomUUID().toString(),
                    campaignId = nextTask.campaignId,
                    campaignTitle = "Campaña: ${nextTask.adProductName}",
                    category = nextTask.category,
                    adId = nextTask.adId,
                    adProductName = nextTask.adProductName,
                    groupId = nextTask.groupId,
                    groupName = nextTask.groupName,
                    messageSnippet = nextTask.message.take(80),
                    status = "abierto_en_whatsapp",
                    observations = "${outcome.statusMessage} (Abierto desde notificación rápida)",
                    timestamp = now,
                    attempts = updated.attempts
                )
            )
        }
    }

    private suspend fun refreshNotificationOrStop(): Boolean {
        val dao = AppDatabase.getDatabase(applicationContext).dao()
        val runningCampaigns = dao.getActiveRunningCampaigns()
        val allTasks = dao.getAllQueueItemsList()

        val pendingTasks = allTasks.filter {
            it.status in listOf("preparado", "en_cola_servidor", "reintento_programado", "abierto_en_whatsapp")
        }
        val confirmedCount = allTasks.count {
            it.status in listOf("confirmado_manualmente", "confirmado_cloud_api", "entregado_webhook", "leido_webhook")
        }
        val nextAssisted = dao.getNextPreparedAssistedTask()

        if (runningCampaigns.isEmpty() || pendingTasks.isEmpty()) {
            stopForegroundSafely()
            return false
        }

        val title = if (nextAssisted != null) {
            "Siguiente: ${nextAssisted.groupName} (${confirmedCount}/${allTasks.size} conf.)"
        } else {
            "Campaña en Curso • Confirmados: $confirmedCount/${allTasks.size}"
        }

        val body = if (nextAssisted != null) {
            "Toca 'Siguiente en WA' para abrir WhatsApp con '${nextAssisted.adProductName}' o abre SHADOWHAT para confirmar."
        } else {
            "Sincronizando envíos en servidor Cloud API (${pendingTasks.size} en proceso)."
        }

        val notification = buildCampaignNotification(
            title = title,
            body = body,
            hasNextAssisted = nextAssisted != null
        )
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, notification)
        return true
    }

    private fun promoteToForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopForegroundSafely() {
        monitorJob?.cancel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun buildCampaignNotification(
        title: String,
        body: String,
        hasNextAssisted: Boolean
    ): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPending = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openAppPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (hasNextAssisted) {
            val nextIntent = Intent(this, CampaignForegroundService::class.java).apply {
                action = ACTION_DISPATCH_NEXT
            }
            val nextPending = PendingIntent.getService(
                this,
                1,
                nextIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_media_next, "Siguiente en WA", nextPending)
        }

        val pauseIntent = Intent(this, CampaignForegroundService::class.java).apply {
            action = ACTION_PAUSE_CAMPAIGN
        }
        val pausePending = PendingIntent.getService(
            this,
            2,
            pauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        builder.addAction(android.R.drawable.ic_media_pause, "Pausar", pausePending)

        val stopIntent = Intent(this, CampaignForegroundService::class.java).apply {
            action = ACTION_STOP_CAMPAIGN
        }
        val stopPending = PendingIntent.getService(
            this,
            3,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        builder.addAction(android.R.drawable.ic_delete, "Detener", stopPending)

        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SHADOWHAT — Servicio de Campaña Activo",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificación visible con controles rápidos mientras una campaña está en curso"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
