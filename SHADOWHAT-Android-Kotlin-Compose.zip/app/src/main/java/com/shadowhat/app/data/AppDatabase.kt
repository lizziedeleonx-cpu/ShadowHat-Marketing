package com.shadowhat.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        AdEntity::class,
        GroupEntity::class,
        CampaignEntity::class,
        TaskQueueEntity::class,
        HistoryEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ShadowHatDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `ads` (
                        `id` TEXT NOT NULL,
                        `productName` TEXT NOT NULL,
                        `description` TEXT NOT NULL,
                        `price` TEXT NOT NULL,
                        `photoUri` TEXT,
                        `videoUri` TEXT,
                        `mediaMimeType` TEXT,
                        `status` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL("ALTER TABLE `whatsapp_groups` ADD COLUMN `description` TEXT")
                db.execSQL("ALTER TABLE `whatsapp_groups` ADD COLUMN `isActive` INTEGER NOT NULL DEFAULT 1")

                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `adId` TEXT")
                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `adProductName` TEXT")
                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `price` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `mediaUri` TEXT")
                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `mediaMimeType` TEXT")

                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `adId` TEXT")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `adProductName` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `price` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `mediaUri` TEXT")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `mediaMimeType` TEXT")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `observations` TEXT")

                db.execSQL("ALTER TABLE `campaign_history` ADD COLUMN `adId` TEXT")
                db.execSQL("ALTER TABLE `campaign_history` ADD COLUMN `adProductName` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `campaign_history` ADD COLUMN `observations` TEXT")
            }
        }

        /**
         * Migración no destructiva v2 -> v3:
         * Añade soporte para categorías de campañas, tipos de destino (Cloud API / Asistido),
         * respeto a bajas (optedOut), prevención de duplicados (idempotencyKey) y WAMID verificable.
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `whatsapp_groups` ADD COLUMN `destinationType` TEXT NOT NULL DEFAULT 'GROUP_MANUAL'")
                db.execSQL("ALTER TABLE `whatsapp_groups` ADD COLUMN `recipientAddress` TEXT")
                db.execSQL("ALTER TABLE `whatsapp_groups` ADD COLUMN `optedOut` INTEGER NOT NULL DEFAULT 0")

                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `category` TEXT NOT NULL DEFAULT 'General'")
                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `executionMode` TEXT NOT NULL DEFAULT 'ANDROID_ASSISTED'")
                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `templateName` TEXT")
                db.execSQL("ALTER TABLE `campaigns` ADD COLUMN `rateLimitMps` INTEGER NOT NULL DEFAULT 10")

                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `idempotencyKey` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `category` TEXT NOT NULL DEFAULT 'General'")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `destinationType` TEXT NOT NULL DEFAULT 'GROUP_MANUAL'")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `recipientAddress` TEXT")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `nextRetryAt` INTEGER")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `wamid` TEXT")
                db.execSQL("ALTER TABLE `task_queue` ADD COLUMN `isPermanentError` INTEGER NOT NULL DEFAULT 0")

                // Poblar idempotencyKey determinista para filas existentes antes de crear el índice único
                db.execSQL("UPDATE `task_queue` SET `idempotencyKey` = `campaignId` || ':' || `groupId` || ':' || `id` WHERE `idempotencyKey` = ''")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_task_queue_idempotencyKey` ON `task_queue` (`idempotencyKey`)")

                db.execSQL("ALTER TABLE `campaign_history` ADD COLUMN `category` TEXT NOT NULL DEFAULT 'General'")
                db.execSQL("ALTER TABLE `campaign_history` ADD COLUMN `wamid` TEXT")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shadowhat_database"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
