package com.shadowhat.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.gson.Gson
import com.shadowhat.app.data.*
import com.shadowhat.app.dispatcher.CloudCampaignClient
import com.shadowhat.app.dispatcher.WhatsAppDispatcher
import com.shadowhat.app.service.CampaignForegroundService
import com.shadowhat.app.service.CampaignWorker
import com.shadowhat.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class BackupPayload(
    val app: String = "SHADOWHAT",
    val version: Int = 3,
    val timestamp: Long = System.currentTimeMillis(),
    val ads: List<AdEntity> = emptyList(),
    val groups: List<GroupEntity> = emptyList(),
    val campaigns: List<CampaignEntity> = emptyList(),
    val history: List<HistoryEntity> = emptyList()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = AppDatabase.getDatabase(this)
        val dao = database.dao()

        setContent {
            ShadowHatTheme {
                ShadowHatApp(dao)
            }
        }
    }
}

enum class Screen(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    DASHBOARD("Inicio", Icons.Default.Dashboard),
    ADS("Anuncios", Icons.Default.Campaign),
    GROUPS("Destinos", Icons.Default.Group),
    CAMPAIGNS("Campañas", Icons.Default.Send),
    HISTORY("Historial", Icons.Default.History),
    SETTINGS("Ajustes", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShadowHatApp(dao: ShadowHatDao) {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(Screen.DASHBOARD) }
    var preselectedGroupIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var preselectedAdId by remember { mutableStateOf<String?>(null) }

    val ads by dao.getAllAds().collectAsState(initial = emptyList())
    val groups by dao.getAllGroups().collectAsState(initial = emptyList())
    val campaigns by dao.getAllCampaigns().collectAsState(initial = emptyList())
    val queue by dao.getAllQueueItems().collectAsState(initial = emptyList())
    val history by dao.getAllHistory().collectAsState(initial = emptyList())

    val coroutineScope = rememberCoroutineScope()
    val pendingCount = queue.count {
        it.status in listOf("preparado", "en_cola_servidor", "reintento_programado", "abierto_en_whatsapp", "pending")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(CrimsonPrimary)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SHADOWHAT",
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp,
                            color = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BlackOnyx,
                    titleContentColor = WhiteText
                ),
                actions = {
                    Text(
                        text = if (pendingCount > 0) "COLA ACTIVA: $pendingCount" else "WA BUSINESS v3.0",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CrimsonPrimary,
                        modifier = Modifier.padding(end = 16.dp)
                    )
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = BlackOnyx,
                tonalElevation = 8.dp
            ) {
                Screen.values().forEach { screen ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { currentScreen = screen },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (screen == Screen.CAMPAIGNS && pendingCount > 0) {
                                        Badge(containerColor = CrimsonPrimary) {
                                            Text(pendingCount.toString(), color = Color.White)
                                        }
                                    }
                                }
                            ) {
                                Icon(screen.icon, contentDescription = screen.title)
                            }
                        },
                        label = { Text(screen.title, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CrimsonPrimary,
                            selectedTextColor = CrimsonPrimary,
                            indicatorColor = DarkGraphite,
                            unselectedIconColor = GraySubtext,
                            unselectedTextColor = GraySubtext
                        )
                    )
                }
            }
        },
        containerColor = BlackOnyx
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(BlackOnyx)
        ) {
            when (currentScreen) {
                Screen.DASHBOARD -> DashboardContent(
                    ads = ads,
                    groups = groups,
                    campaigns = campaigns,
                    queue = queue,
                    history = history,
                    onNavigate = { currentScreen = it }
                )
                Screen.ADS -> AdsContent(
                    ads = ads,
                    onSaveAd = { ad -> coroutineScope.launch { dao.insertAd(ad) } },
                    onDuplicateAd = { ad ->
                        coroutineScope.launch {
                            val now = System.currentTimeMillis()
                            val copy = ad.copy(
                                id = UUID.randomUUID().toString(),
                                productName = "${ad.productName} (Copia)",
                                createdAt = now,
                                updatedAt = now
                            )
                            dao.insertAd(copy)
                            Toast.makeText(context, "Anuncio duplicado", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onDeleteAd = { ad -> coroutineScope.launch { dao.deleteAd(ad) } },
                    onUseInCampaign = { ad ->
                        preselectedAdId = ad.id
                        currentScreen = Screen.CAMPAIGNS
                    }
                )
                Screen.GROUPS -> GroupsContent(
                    groups = groups,
                    onSaveGroup = { grp -> coroutineScope.launch { dao.insertGroup(grp) } },
                    onDeleteGroup = { grp -> coroutineScope.launch { dao.deleteGroup(grp) } },
                    onCampaignWithSelected = { ids ->
                        preselectedGroupIds = ids
                        currentScreen = Screen.CAMPAIGNS
                    }
                )
                Screen.CAMPAIGNS -> CampaignsAndQueueContent(
                    dao = dao,
                    ads = ads,
                    groups = groups,
                    campaigns = campaigns,
                    queue = queue,
                    initialAdId = preselectedAdId,
                    initialGroupIds = preselectedGroupIds,
                    onPrepareCampaign = { campaign, tasks, historyItems, targets ->
                        coroutineScope.launch {
                            dao.insertCampaign(campaign)
                            // Inserción con prevención estricta de duplicados por idempotencyKey
                            dao.insertQueueItemsIgnoreDuplicates(tasks)
                            dao.insertHistoryList(historyItems)

                            if (campaign.executionMode == "CLOUD_API") {
                                val res = CloudCampaignClient.submitCampaignToServer(
                                    context = context,
                                    campaign = campaign,
                                    targets = targets,
                                    autoStart = campaign.status == "en_curso"
                                )
                                res.onSuccess {
                                    CloudCampaignClient.syncServerStateToRoom(context, dao)
                                    Toast.makeText(context, "Campaña enviada al Servidor Cloud", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    Toast.makeText(context, "Aviso Cloud: ${err.message}", Toast.LENGTH_LONG).show()
                                }
                            } else {
                                Toast.makeText(
                                    context,
                                    "Campaña preparada para ${tasks.size} destino(s)",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                            // Iniciar servicio en primer plano con notificación visible e interactiva (estilo WhatsTool)
                            CampaignForegroundService.startOrUpdate(context)

                            WorkManager.getInstance(context).enqueue(
                                OneTimeWorkRequestBuilder<CampaignWorker>().build()
                            )
                        }
                    },
                    onUpdateCampaign = { camp -> coroutineScope.launch { dao.updateCampaign(camp) } },
                    onCancelCampaign = { camp ->
                        coroutineScope.launch {
                            dao.updateCampaign(camp.copy(status = "cancelado", completedAt = System.currentTimeMillis()))
                            dao.cancelPendingTasksForCampaign(camp.id)
                            if (camp.executionMode == "CLOUD_API") {
                                CloudCampaignClient.controlServerCampaign(context, camp.id, "cancel")
                            }
                            CampaignForegroundService.stop(context)
                            Toast.makeText(context, "Campaña detenida y cancelada inmediatamente", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onUpdateTask = { task -> coroutineScope.launch { dao.updateQueueItem(task) } },
                    onInsertHistory = { record -> coroutineScope.launch { dao.insertHistory(record) } },
                    onClearCompleted = { coroutineScope.launch { dao.clearCompletedQueueItems() } }
                )
                Screen.HISTORY -> HistoryContent(
                    history = history,
                    onUpdateHistory = { item -> coroutineScope.launch { dao.updateHistory(item) } },
                    onClear = { coroutineScope.launch { dao.clearHistory() } }
                )
                Screen.SETTINGS -> SettingsContent(dao = dao)
            }
        }
    }
}

@Composable
fun DashboardContent(
    ads: List<AdEntity>,
    groups: List<GroupEntity>,
    campaigns: List<CampaignEntity>,
    queue: List<TaskQueueEntity>,
    history: List<HistoryEntity>,
    onNavigate: (Screen) -> Unit
) {
    val activeAds = ads.count { it.status == "Activo" }
    val activeGroups = groups.count { it.isActive && !it.optedOut }
    val optedOutCount = groups.count { it.optedOut }
    val pendingTasks = queue.count {
        it.status in listOf("preparado", "en_cola_servidor", "reintento_programado", "abierto_en_whatsapp")
    }
    val confirmedSent = history.count {
        it.status in listOf("confirmado_manualmente", "confirmado_cloud_api", "entregado_webhook", "leido_webhook", "sent_verified")
    }
    val runningCampaigns = campaigns.count { it.status == "en_curso" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CrimsonPrimary.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "SHADOWHAT — ARQUITECTURA HÍBRIDA (CLOUD API + ASISTIDO ANDROID)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CrimsonPrimary
                    )
                    Text(
                        text = "• Envíos en Segundo Plano Real (Servidor Cloud API): para destinatarios con opt-in (Plantillas 1:1) o grupos oficiales OBA (máx. 8 miembros). Continúa aunque bloquees la pantalla o apagues el teléfono.\n• Modo Asistido Android: para grupos tradicionales existentes de WhatsApp Business donde Meta no ofrece API pública.",
                        fontSize = 12.sp,
                        color = WhiteText
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard("Anuncios", "${ads.size} ($activeAds act.)", Modifier.weight(1f))
                StatCard("Destinos Hábiles", "$activeGroups (${optedOutCount} bajas)", Modifier.weight(1f))
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard("En Cola / Curso", "$pendingTasks ($runningCampaigns camp.)", Modifier.weight(1f))
                StatCard("Confirmados", confirmedSent.toString(), Modifier.weight(1f))
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onNavigate(Screen.ADS) },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) {
                    Text("CREAR ANUNCIO", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                }
                Button(
                    onClick = { onNavigate(Screen.CAMPAIGNS) },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) {
                    Text("GESTIONAR CAMPAÑAS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = DarkGraphite),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontSize = 11.sp, color = GraySubtext)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = WhiteText)
        }
    }
}

@Composable
fun AdsContent(
    ads: List<AdEntity>,
    onSaveAd: (AdEntity) -> Unit,
    onDuplicateAd: (AdEntity) -> Unit,
    onDeleteAd: (AdEntity) -> Unit,
    onUseInCampaign: (AdEntity) -> Unit
) {
    val context = LocalContext.current
    val formatter = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }

    var showDialog by remember { mutableStateOf(false) }
    var editingAd by remember { mutableStateOf<AdEntity?>(null) }

    var productName by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<String?>(null) }
    var videoUri by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Activo") }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            WhatsAppDispatcher.persistMediaUriPermission(context, uri)
            photoUri = uri.toString()
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            WhatsAppDispatcher.persistMediaUriPermission(context, uri)
            videoUri = uri.toString()
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Catálogo de Anuncios (${ads.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = WhiteText)
            Button(
                onClick = {
                    editingAd = null
                    productName = ""
                    description = ""
                    price = ""
                    photoUri = null
                    videoUri = null
                    status = "Activo"
                    showDialog = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("+ Nuevo Anuncio", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (ads.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No hay anuncios registrados. Crea tu primer producto publicitario.", color = GraySubtext)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(ads, key = { it.id }) { ad ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(ad.productName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = WhiteText)
                                Text(
                                    text = "${ad.price} • ${ad.status}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CrimsonPrimary
                                )
                            }
                            Text(ad.description, fontSize = 13.sp, color = GraySubtext, maxLines = 3)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!ad.photoUri.isNullOrBlank()) {
                                    Text("📷 Foto URI", fontSize = 11.sp, color = Color(0xFF10B981))
                                }
                                if (!ad.videoUri.isNullOrBlank()) {
                                    Text("🎥 Video URI", fontSize = 11.sp, color = Color(0xFF10B981))
                                }
                                Text("Creado: ${formatter.format(Date(ad.createdAt))}", fontSize = 10.sp, color = GraySubtext)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { onUseInCampaign(ad) }) {
                                    Text("Crear Campaña", color = CrimsonPrimary, fontSize = 12.sp)
                                }
                                TextButton(onClick = { onDuplicateAd(ad) }) {
                                    Text("Duplicar", color = WhiteText, fontSize = 12.sp)
                                }
                                TextButton(
                                    onClick = {
                                        editingAd = ad
                                        productName = ad.productName
                                        description = ad.description
                                        price = ad.price
                                        photoUri = ad.photoUri
                                        videoUri = ad.videoUri
                                        status = ad.status
                                        showDialog = true
                                    }
                                ) {
                                    Text("Editar", color = GraySubtext, fontSize = 12.sp)
                                }
                                IconButton(onClick = { onDeleteAd(ad) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = CrimsonPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text(if (editingAd != null) "Editar Anuncio" else "Registrar Producto / Anuncio", color = WhiteText) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = productName,
                            onValueChange = { productName = it },
                            label = { Text("Nombre del producto *") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it },
                            label = { Text("Precio (ej: $250 MXN)") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Descripción o texto publicitario *") },
                            modifier = Modifier.height(100.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { photoPicker.launch(arrayOf("image/*")) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (photoUri != null) "Foto ✅" else "+ Foto", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = { videoPicker.launch(arrayOf("video/*")) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (videoUri != null) "Video ✅" else "+ Video", fontSize = 11.sp)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Activo", "Borrador", "Inactivo").forEach { st ->
                                FilterChip(
                                    selected = status == st,
                                    onClick = { status = st },
                                    label = { Text(st, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (productName.isNotBlank() && description.isNotBlank()) {
                                val now = System.currentTimeMillis()
                                val mediaMime = when {
                                    !videoUri.isNullOrBlank() -> "video/*"
                                    !photoUri.isNullOrBlank() -> "image/*"
                                    else -> null
                                }
                                onSaveAd(
                                    AdEntity(
                                        id = editingAd?.id ?: UUID.randomUUID().toString(),
                                        productName = productName.trim(),
                                        description = description.trim(),
                                        price = price.trim(),
                                        photoUri = photoUri,
                                        videoUri = videoUri,
                                        mediaMimeType = mediaMime,
                                        status = status,
                                        createdAt = editingAd?.createdAt ?: now,
                                        updatedAt = now
                                    )
                                )
                                showDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("Guardar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDialog = false }) {
                        Text("Cancelar", color = GraySubtext)
                    }
                },
                containerColor = DarkGraphite
            )
        }
    }
}

@Composable
fun GroupsContent(
    groups: List<GroupEntity>,
    onSaveGroup: (GroupEntity) -> Unit,
    onDeleteGroup: (GroupEntity) -> Unit,
    onCampaignWithSelected: (List<String>) -> Unit
) {
    val categories = listOf("Todos", "Ventas", "Clientes VIP", "Distribuidores", "Personal", "General")
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todos") }
    val selectedIds = remember { mutableStateListOf<String>() }

    var editingGroup by remember { mutableStateOf<GroupEntity?>(null) }
    var showModal by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }
    var descriptionInput by remember { mutableStateOf("") }
    var categoryInput by remember { mutableStateOf("Ventas") }
    var destTypeInput by remember { mutableStateOf("GROUP_MANUAL") }
    var addressInput by remember { mutableStateOf("") }
    var isActiveInput by remember { mutableStateOf(true) }
    var optedOutInput by remember { mutableStateOf(false) }

    val filtered = groups.filter { grp ->
        val matchesSearch = grp.name.contains(searchQuery, ignoreCase = true) ||
            (grp.description?.contains(searchQuery, ignoreCase = true) == true) ||
            (grp.recipientAddress?.contains(searchQuery, ignoreCase = true) == true)
        val matchesCat = selectedCategory == "Todos" || grp.category == selectedCategory
        matchesSearch && matchesCat
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Registra grupos manuales de WhatsApp Business (Modo Asistido) o destinatarios con consentimiento E.164 / Grupos OBA (Modo Servidor Cloud API).",
            fontSize = 11.sp,
            color = GraySubtext
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Destinos y Grupos (${groups.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = WhiteText)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selectedIds.isNotEmpty()) {
                    Button(
                        onClick = { onCampaignWithSelected(selectedIds.toList()) },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonDark),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Campaña (${selectedIds.size})", fontSize = 11.sp)
                    }
                }
                Button(
                    onClick = {
                        editingGroup = null
                        nameInput = ""
                        descriptionInput = ""
                        categoryInput = "Ventas"
                        destTypeInput = "GROUP_MANUAL"
                        addressInput = ""
                        isActiveInput = true
                        optedOutInput = false
                        showModal = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+ Destino", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Buscar por nombre, número E.164 o descripción...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { grp ->
                val isSelected = selectedIds.contains(grp.id)
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isSelected,
                            enabled = grp.isActive && !grp.optedOut,
                            onCheckedChange = { checked ->
                                if (checked) selectedIds.add(grp.id) else selectedIds.remove(grp.id)
                            },
                            colors = CheckboxDefaults.colors(checkedColor = CrimsonPrimary)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(grp.name, fontWeight = FontWeight.Bold, color = WhiteText)
                            val typeLabel = when (grp.destinationType) {
                                "RECIPIENT_CLOUD_API" -> "Cloud API 1:1 (${grp.recipientAddress ?: "sin número"})"
                                "GROUP_CLOUD_API" -> "Grupo Cloud API OBA"
                                else -> "Grupo Manual WA Business"
                            }
                            Text(
                                text = "${grp.category} • $typeLabel • ${if (grp.optedOut) "BAJA SOLICITADA (OPT-OUT)" else if (grp.isActive) "ACTIVO" else "INACTIVO"}",
                                fontSize = 11.sp,
                                color = when {
                                    grp.optedOut -> CrimsonPrimary
                                    grp.isActive -> Color(0xFF10B981)
                                    else -> GraySubtext
                                }
                            )
                            if (!grp.description.isNullOrBlank()) {
                                Text(grp.description, fontSize = 11.sp, color = GraySubtext)
                            }
                        }
                        Switch(
                            checked = grp.isActive && !grp.optedOut,
                            onCheckedChange = { active ->
                                onSaveGroup(grp.copy(isActive = active, updatedAt = System.currentTimeMillis()))
                            }
                        )
                        IconButton(
                            onClick = {
                                editingGroup = grp
                                nameInput = grp.name
                                descriptionInput = grp.description ?: ""
                                categoryInput = grp.category
                                destTypeInput = grp.destinationType
                                addressInput = grp.recipientAddress ?: ""
                                isActiveInput = grp.isActive
                                optedOutInput = grp.optedOut
                                showModal = true
                            }
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Editar", tint = GraySubtext)
                        }
                        IconButton(onClick = { onDeleteGroup(grp) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = CrimsonPrimary)
                        }
                    }
                }
            }
        }

        if (showModal) {
            AlertDialog(
                onDismissRequest = { showModal = false },
                title = { Text(if (editingGroup != null) "Editar Destino" else "Registrar Destino / Grupo", color = WhiteText) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Nombre del grupo o destinatario *") }
                        )
                        OutlinedTextField(
                            value = categoryInput,
                            onValueChange = { categoryInput = it },
                            label = { Text("Categoría (Ventas, Clientes VIP...)") }
                        )
                        Text("Tipo de integración:", fontSize = 11.sp, color = GraySubtext)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "GROUP_MANUAL" to "Grupo Manual (Asistido)",
                                "RECIPIENT_CLOUD_API" to "Destinatario Cloud API 1:1",
                                "GROUP_CLOUD_API" to "Grupo Cloud API (OBA ≤8)"
                            ).forEach { (code, label) ->
                                FilterChip(
                                    selected = destTypeInput == code,
                                    onClick = { destTypeInput = code },
                                    label = { Text(label, fontSize = 10.sp) }
                                )
                            }
                        }
                        if (destTypeInput != "GROUP_MANUAL") {
                            OutlinedTextField(
                                value = addressInput,
                                onValueChange = { addressInput = it },
                                label = { Text("Número E.164 (+521...) o Group ID Oficial") }
                            )
                        }
                        OutlinedTextField(
                            value = descriptionInput,
                            onValueChange = { descriptionInput = it },
                            label = { Text("Descripción opcional") }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = isActiveInput, onCheckedChange = { isActiveInput = it })
                            Text("Destino Activo", color = WhiteText, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = optedOutInput, onCheckedChange = { optedOutInput = it })
                            Text("Baja solicitada (Opt-Out: bloquear envíos)", color = CrimsonPrimary, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (nameInput.isNotBlank()) {
                                val now = System.currentTimeMillis()
                                val entity = GroupEntity(
                                    id = editingGroup?.id ?: UUID.randomUUID().toString(),
                                    name = nameInput.trim(),
                                    description = descriptionInput.trim().ifBlank { null },
                                    category = categoryInput.trim().ifBlank { "General" },
                                    isActive = isActiveInput,
                                    destinationType = destTypeInput,
                                    recipientAddress = addressInput.trim().ifBlank { null },
                                    optedOut = optedOutInput,
                                    createdAt = editingGroup?.createdAt ?: now,
                                    updatedAt = now
                                )
                                onSaveGroup(entity)
                                showModal = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("Guardar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showModal = false }) {
                        Text("Cancelar", color = GraySubtext)
                    }
                },
                containerColor = DarkGraphite
            )
        }
    }
}

@Composable
fun CampaignsAndQueueContent(
    dao: ShadowHatDao,
    ads: List<AdEntity>,
    groups: List<GroupEntity>,
    campaigns: List<CampaignEntity>,
    queue: List<TaskQueueEntity>,
    initialAdId: String?,
    initialGroupIds: List<String>,
    onPrepareCampaign: (CampaignEntity, List<TaskQueueEntity>, List<HistoryEntity>, List<GroupEntity>) -> Unit,
    onUpdateCampaign: (CampaignEntity) -> Unit,
    onCancelCampaign: (CampaignEntity) -> Unit,
    onUpdateTask: (TaskQueueEntity) -> Unit,
    onInsertHistory: (HistoryEntity) -> Unit,
    onClearCompleted: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val campaignCategories = listOf("Ofertas Flash", "Lanzamientos", "Clientes VIP", "Liquidación", "General")

    // Filtrar solo destinos activos y que NO hayan solicitado baja (Opt-Out)
    val eligibleGroups = remember(groups) { groups.filter { it.isActive && !it.optedOut } }

    var selectedAdId by remember(initialAdId, ads) {
        mutableStateOf(initialAdId ?: ads.firstOrNull()?.id)
    }
    val selectedAd = ads.find { it.id == selectedAdId }

    var campaignCategory by remember { mutableStateOf("Ofertas Flash") }
    var executionMode by remember { mutableStateOf("ANDROID_ASSISTED") }
    var rateLimitMps by remember { mutableStateOf("10") }
    var filterCategory by remember { mutableStateOf("Todas") }

    val selectedGroupIds = remember { mutableStateListOf<String>() }
    LaunchedEffect(eligibleGroups, initialGroupIds) {
        if (initialGroupIds.isNotEmpty()) {
            selectedGroupIds.clear()
            selectedGroupIds.addAll(initialGroupIds.filter { id -> eligibleGroups.any { it.id == id } })
        } else if (selectedGroupIds.isEmpty()) {
            selectedGroupIds.addAll(eligibleGroups.map { it.id })
        }
    }

    var verifyingTask by remember { mutableStateOf<TaskQueueEntity?>(null) }
    var observationsInput by remember { mutableStateOf("") }

    val formattedPreview = remember(selectedAd) {
        if (selectedAd == null) ""
        else buildString {
            append("*${selectedAd.productName}*")
            if (selectedAd.price.isNotBlank()) append(" — ${selectedAd.price}")
            append("\n\n${selectedAd.description}")
        }
    }

    val filteredCampaigns = remember(campaigns, filterCategory) {
        if (filterCategory == "Todas") campaigns else campaigns.filter { it.category == filterCategory }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("1. Configurar Nueva Campaña por Categoría", fontWeight = FontWeight.Black, fontSize = 16.sp, color = WhiteText)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                campaignCategories.forEach { cat ->
                    FilterChip(
                        selected = campaignCategory == cat,
                        onClick = { campaignCategory = cat },
                        label = { Text(cat, fontSize = 11.sp) }
                    )
                }
            }
        }

        item {
            Text("2. Elegir Anuncio y Modo de Ejecución", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = WhiteText)
            if (ads.isEmpty()) {
                Text("Primero registra un producto en la pestaña 'Anuncios'.", fontSize = 12.sp, color = CrimsonPrimary)
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ads.forEach { ad ->
                        FilterChip(
                            selected = selectedAdId == ad.id,
                            onClick = { selectedAdId = ad.id },
                            label = { Text("${ad.productName} (${ad.price})", fontSize = 11.sp) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = executionMode == "ANDROID_ASSISTED",
                    onClick = { executionMode = "ANDROID_ASSISTED" },
                    label = { Text("Modo Asistido Android (Grupos WA)", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = executionMode == "CLOUD_API",
                    onClick = { executionMode = "CLOUD_API" },
                    label = { Text("Servidor Cloud API (2º Plano Real)", fontSize = 11.sp) }
                )
            }

            if (executionMode == "CLOUD_API") {
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = rateLimitMps,
                    onValueChange = { rateLimitMps = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Límite oficial de plataforma (MPS: 1-80 msgs/seg)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                val incompatibleManualCount = eligibleGroups.count {
                    selectedGroupIds.contains(it.id) && it.destinationType == "GROUP_MANUAL"
                }
                if (incompatibleManualCount > 0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "⚠️ Verificación de destinos: $incompatibleManualCount destino(s) seleccionados son Grupos Manuales de WhatsApp Business (GROUP_MANUAL). La Cloud API oficial NO puede publicar automáticamente en grupos existentes del teléfono; cámbialos a Destinatario Cloud API 1:1 o usa Modo Asistido Android.",
                        fontSize = 11.sp,
                        color = GoldAccent
                    )
                }
            }
        }

        if (selectedAd != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF005C4B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "Vista previa antes de iniciar [${campaignCategory}]:",
                            fontSize = 10.sp,
                            color = Color(0xFFA7F3D0)
                        )
                        Text(formattedPreview, fontSize = 13.sp, color = Color.White)
                        if (!selectedAd.photoUri.isNullOrBlank() || !selectedAd.videoUri.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Multimedia: ${selectedAd.videoUri ?: selectedAd.photoUri}",
                                fontSize = 10.sp,
                                color = Color(0xFFA7F3D0)
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "3. Destinos Hábiles (${selectedGroupIds.size}/${eligibleGroups.size})",
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Button(
                    onClick = {
                        val ad = selectedAd ?: return@Button
                        val targets = eligibleGroups.filter { selectedGroupIds.contains(it.id) }
                        if (targets.isEmpty()) return@Button
                        val now = System.currentTimeMillis()
                        val campId = UUID.randomUUID().toString()
                        val mediaUri = ad.videoUri ?: ad.photoUri
                        val mps = (rateLimitMps.toIntOrNull() ?: 10).coerceIn(1, 80)

                        val campaign = CampaignEntity(
                            id = campId,
                            title = "Campaña: ${ad.productName}",
                            category = campaignCategory,
                            adId = ad.id,
                            adProductName = ad.productName,
                            message = formattedPreview,
                            price = ad.price,
                            mediaUri = mediaUri,
                            mediaMimeType = ad.mediaMimeType,
                            targetGroupIdsJson = targets.joinToString(",") { it.id },
                            status = "en_curso",
                            executionMode = executionMode,
                            rateLimitMps = mps,
                            assistedMode = executionMode == "ANDROID_ASSISTED",
                            createdAt = now
                        )

                        val initialTaskStatus = if (executionMode == "CLOUD_API") "en_cola_servidor" else "preparado"
                        val tasks = targets.map { grp ->
                            TaskQueueEntity(
                                id = UUID.randomUUID().toString(),
                                idempotencyKey = "$campId:${grp.id}",
                                campaignId = campId,
                                category = campaignCategory,
                                adId = ad.id,
                                adProductName = ad.productName,
                                groupId = grp.id,
                                groupName = grp.name,
                                destinationType = grp.destinationType,
                                recipientAddress = grp.recipientAddress,
                                message = formattedPreview,
                                price = ad.price,
                                mediaUri = mediaUri,
                                mediaMimeType = ad.mediaMimeType,
                                status = initialTaskStatus
                            )
                        }
                        val historyEntries = targets.map { grp ->
                            HistoryEntity(
                                id = UUID.randomUUID().toString(),
                                campaignId = campId,
                                campaignTitle = campaign.title,
                                category = campaignCategory,
                                adId = ad.id,
                                adProductName = ad.productName,
                                groupId = grp.id,
                                groupName = grp.name,
                                messageSnippet = formattedPreview.take(80),
                                status = initialTaskStatus,
                                observations = if (executionMode == "CLOUD_API") {
                                    "Encolado hacia servidor Cloud API (sin duplicados)"
                                } else {
                                    "Preparado en cola local para envío asistido"
                                },
                                timestamp = now
                            )
                        }
                        onPrepareCampaign(campaign, tasks, historyEntries, targets)
                    },
                    enabled = selectedAd != null && selectedGroupIds.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Iniciar Campaña (${selectedGroupIds.size})", fontSize = 12.sp)
                }
            }
        }

        items(eligibleGroups, key = { "sel_${it.id}" }) { grp ->
            val checked = selectedGroupIds.contains(grp.id)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (checked) selectedGroupIds.remove(grp.id) else selectedGroupIds.add(grp.id)
                    }
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = checked,
                    onCheckedChange = { isChecked ->
                        if (isChecked) selectedGroupIds.add(grp.id) else selectedGroupIds.remove(grp.id)
                    }
                )
                Text("${grp.name} [${grp.category}]", color = WhiteText, fontSize = 12.sp)
            }
        }

        // Control de Campañas Activas (Iniciar, Pausar, Reanudar, Cancelar Inmediatamente)
        if (campaigns.isNotEmpty()) {
            item {
                Divider(color = DarkGraphite, thickness = 1.dp)
                Spacer(modifier = Modifier.height(6.dp))
                Text("4. Control de Campañas (Pausar / Reanudar / Detener)", fontWeight = FontWeight.Black, fontSize = 15.sp, color = WhiteText)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    (listOf("Todas") + campaignCategories).forEach { cat ->
                        FilterChip(
                            selected = filterCategory == cat,
                            onClick = { filterCategory = cat },
                            label = { Text(cat, fontSize = 10.sp) }
                        )
                    }
                }
            }

            items(filteredCampaigns.take(8), key = { "camp_${it.id}" }) { camp ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${camp.title} [${camp.category}]", fontWeight = FontWeight.Bold, color = WhiteText, fontSize = 13.sp)
                            Text(
                                text = "${camp.status.uppercase()} • ${camp.executionMode}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (camp.status) {
                                    "en_curso" -> Color(0xFF10B981)
                                    "pausado" -> GoldAccent
                                    "cancelado" -> CrimsonPrimary
                                    else -> GraySubtext
                                }
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (camp.status == "en_curso") {
                                OutlinedButton(
                                    onClick = {
                                        onUpdateCampaign(camp.copy(status = "pausado"))
                                        CampaignForegroundService.pause(context)
                                        if (camp.executionMode == "CLOUD_API") {
                                            coroutineScope.launch {
                                                CloudCampaignClient.controlServerCampaign(context, camp.id, "pause")
                                            }
                                        }
                                    }
                                ) {
                                    Text("Pausar", fontSize = 11.sp, color = GoldAccent)
                                }
                            }
                            if (camp.status == "pausado" || camp.status == "preparado") {
                                Button(
                                    onClick = {
                                        // Reanudar campaña evitando duplicar tareas ya confirmadas
                                        onUpdateCampaign(camp.copy(status = "en_curso"))
                                        CampaignForegroundService.startOrUpdate(context)
                                        if (camp.executionMode == "CLOUD_API") {
                                            coroutineScope.launch {
                                                CloudCampaignClient.controlServerCampaign(context, camp.id, "resume")
                                                CloudCampaignClient.syncServerStateToRoom(context, dao)
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    Text("Reanudar (Sin Duplicar)", fontSize = 11.sp, color = Color.White)
                                }
                            }
                            if (camp.status != "cancelado" && camp.status != "completado") {
                                Button(
                                    onClick = { onCancelCampaign(camp) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                                ) {
                                    Text("Detener Ahora", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Divider(color = DarkGraphite, thickness = 1.dp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("5. Cola Persistente por Destinatario (${queue.size})", fontWeight = FontWeight.Black, fontSize = 16.sp, color = WhiteText)
                Row {
                    TextButton(
                        onClick = {
                            coroutineScope.launch {
                                val n = CloudCampaignClient.syncServerStateToRoom(context, dao)
                                Toast.makeText(context, "Sincronizados $n cambios del servidor", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        Text("Sync Cloud", color = GoldAccent, fontSize = 11.sp)
                    }
                    TextButton(onClick = onClearCompleted) {
                        Text("Limpiar finalizados", color = CrimsonPrimary, fontSize = 11.sp)
                    }
                }
            }
        }

        items(queue, key = { "q_${it.id}" }) { task ->
            val parentCampaign = campaigns.find { it.id == task.campaignId }
            val isCampaignPausedOrCancelled = parentCampaign?.status in listOf("pausado", "cancelado")

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${task.adProductName} → ${task.groupName}", fontWeight = FontWeight.Bold, color = WhiteText)
                        Text(
                            text = "Estado: ${task.status.uppercase()} • Intentos: ${task.attempts}/${task.maxAttempts}",
                            fontSize = 11.sp,
                            color = when (task.status) {
                                "confirmado_manualmente", "confirmado_cloud_api", "entregado_webhook", "leido_webhook" -> Color(0xFF10B981)
                                "abierto_en_whatsapp", "en_cola_servidor", "reintento_programado" -> GoldAccent
                                "omitido_baja", "cancelado", "error" -> CrimsonPrimary
                                else -> GraySubtext
                            }
                        )
                        if (!task.wamid.isNullOrBlank()) {
                            Text("WAMID: ${task.wamid}", fontSize = 10.sp, color = Color(0xFF10B981))
                        }
                        if (!task.errorMessage.isNullOrBlank()) {
                            Text("Error: ${task.errorMessage}", fontSize = 10.sp, color = CrimsonPrimary)
                        }
                    }
                    if (
                        task.status !in listOf("confirmado_manualmente", "confirmado_cloud_api", "omitido_baja", "cancelado") &&
                        !isCampaignPausedOrCancelled
                    ) {
                        Button(
                            onClick = {
                                val outcome = WhatsAppDispatcher.dispatchAdToWhatsApp(
                                    context = context,
                                    formattedMessage = task.message,
                                    targetGroupHint = task.groupName,
                                    mediaUriString = task.mediaUri,
                                    mediaMimeType = task.mediaMimeType,
                                    preferBusiness = true
                                )
                                val now = System.currentTimeMillis()
                                if (outcome.success) {
                                    val updated = task.copy(
                                        status = "abierto_en_whatsapp",
                                        attempts = task.attempts + 1,
                                        lastAttemptAt = now
                                    )
                                    onUpdateTask(updated)
                                    onInsertHistory(
                                        HistoryEntity(
                                            id = UUID.randomUUID().toString(),
                                            campaignId = task.campaignId,
                                            campaignTitle = "Campaña: ${task.adProductName}",
                                            category = task.category,
                                            adId = task.adId,
                                            adProductName = task.adProductName,
                                            groupId = task.groupId,
                                            groupName = task.groupName,
                                            messageSnippet = task.message.take(80),
                                            status = "abierto_en_whatsapp",
                                            observations = outcome.statusMessage,
                                            timestamp = now,
                                            attempts = updated.attempts
                                        )
                                    )
                                    observationsInput = ""
                                    verifyingTask = updated
                                } else {
                                    val updated = task.copy(
                                        status = "error",
                                        attempts = task.attempts + 1,
                                        errorMessage = outcome.statusMessage
                                    )
                                    onUpdateTask(updated)
                                    onInsertHistory(
                                        HistoryEntity(
                                            id = UUID.randomUUID().toString(),
                                            campaignId = task.campaignId,
                                            campaignTitle = "Campaña: ${task.adProductName}",
                                            category = task.category,
                                            adId = task.adId,
                                            adProductName = task.adProductName,
                                            groupId = task.groupId,
                                            groupName = task.groupName,
                                            messageSnippet = task.message.take(80),
                                            status = "error",
                                            observations = outcome.statusMessage,
                                            timestamp = now,
                                            attempts = updated.attempts
                                        )
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (task.status == "error") "Reintentar WA" else "Abrir WA", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    if (verifyingTask != null) {
        val current = verifyingTask!!
        AlertDialog(
            onDismissRequest = { verifyingTask = null },
            title = { Text("Registrar Confirmación Verificable", color = WhiteText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Se abrió WhatsApp para '${current.adProductName}' hacia '${current.groupName}'.\n\nNunca marcamos un mensaje como enviado sin confirmación real. ¿Confirmas que el envío se completó en WhatsApp?",
                        color = GraySubtext,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = observationsInput,
                        onValueChange = { observationsInput = it },
                        label = { Text("Observaciones opcionales") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val now = System.currentTimeMillis()
                        val obs = observationsInput.trim().ifBlank { "Envío confirmado manualmente por el usuario" }
                        onUpdateTask(current.copy(status = "confirmado_manualmente", verifiedAt = now, observations = obs))
                        onInsertHistory(
                            HistoryEntity(
                                id = UUID.randomUUID().toString(),
                                campaignId = current.campaignId,
                                campaignTitle = "Campaña: ${current.adProductName}",
                                category = current.category,
                                adId = current.adId,
                                adProductName = current.adProductName,
                                groupId = current.groupId,
                                groupName = current.groupName,
                                messageSnippet = current.message.take(80),
                                status = "confirmado_manualmente",
                                observations = obs,
                                timestamp = now,
                                attempts = current.attempts
                            )
                        )
                        verifyingTask = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text("Confirmado Manualmente", color = Color.White, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        val now = System.currentTimeMillis()
                        val obs = observationsInput.trim().ifBlank { "No enviado / error reportado por el usuario" }
                        onUpdateTask(current.copy(status = "error", observations = obs, errorMessage = obs))
                        onInsertHistory(
                            HistoryEntity(
                                id = UUID.randomUUID().toString(),
                                campaignId = current.campaignId,
                                campaignTitle = "Campaña: ${current.adProductName}",
                                category = current.category,
                                adId = current.adId,
                                adProductName = current.adProductName,
                                groupId = current.groupId,
                                groupName = current.groupName,
                                messageSnippet = current.message.take(80),
                                status = "error",
                                observations = obs,
                                timestamp = now,
                                attempts = current.attempts
                            )
                        )
                        verifyingTask = null
                    }
                ) {
                    Text("Registrar Fallo", color = CrimsonPrimary, fontSize = 12.sp)
                }
            },
            containerColor = DarkGraphite
        )
    }
}

@Composable
fun HistoryContent(
    history: List<HistoryEntity>,
    onUpdateHistory: (HistoryEntity) -> Unit,
    onClear: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()) }
    var editingHistory by remember { mutableStateOf<HistoryEntity?>(null) }
    var obsText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Historial Verificable (${history.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = WhiteText)
            if (history.isNotEmpty()) {
                TextButton(onClick = onClear) {
                    Text("Vaciar", color = CrimsonPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (history.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Sin registros en el historial.", color = GraySubtext)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { it.id }) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "[${item.category}] ${item.adProductName.ifBlank { item.campaignTitle }} → ${item.groupName}",
                                    fontWeight = FontWeight.Bold,
                                    color = WhiteText,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = item.status.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (item.status) {
                                        "confirmado_manualmente", "confirmado_cloud_api", "entregado_webhook", "leido_webhook", "sent_verified" -> Color(0xFF10B981)
                                        "abierto_en_whatsapp", "en_cola_servidor", "reintento_programado" -> GoldAccent
                                        "preparado" -> Color(0xFF60A5FA)
                                        else -> CrimsonPrimary
                                    }
                                )
                            }
                            Text(item.messageSnippet, fontSize = 12.sp, color = GraySubtext, maxLines = 2)
                            if (!item.wamid.isNullOrBlank()) {
                                Text("WAMID Oficial: ${item.wamid}", fontSize = 10.sp, color = Color(0xFF10B981))
                            }
                            if (!item.observations.isNullOrBlank()) {
                                Text("Obs: ${item.observations}", fontSize = 11.sp, color = WhiteText)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${formatter.format(Date(item.timestamp))} • Intentos: ${item.attempts}",
                                    fontSize = 10.sp,
                                    color = GraySubtext
                                )
                                TextButton(
                                    onClick = {
                                        editingHistory = item
                                        obsText = item.observations ?: ""
                                    }
                                ) {
                                    Text("Editar Obs.", fontSize = 11.sp, color = CrimsonPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (editingHistory != null) {
            val target = editingHistory!!
            AlertDialog(
                onDismissRequest = { editingHistory = null },
                title = { Text("Observaciones del Registro", color = WhiteText) },
                text = {
                    OutlinedTextField(
                        value = obsText,
                        onValueChange = { obsText = it },
                        label = { Text("Observaciones") }
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onUpdateHistory(target.copy(observations = obsText.trim()))
                            editingHistory = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("Guardar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { editingHistory = null }) {
                        Text("Cancelar", color = GraySubtext)
                    }
                },
                containerColor = DarkGraphite
            )
        }
    }
}

@Composable
fun SettingsContent(dao: ShadowHatDao) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val gson = remember { Gson() }
    val availability = remember { WhatsAppDispatcher.checkInstalledWhatsApp(context) }

    var serverUrl by remember { mutableStateOf(CloudCampaignClient.getServerUrl(context)) }
    var clientApiKey by remember { mutableStateOf(CloudCampaignClient.getClientApiKey(context)) }
    var defaultTemplate by remember { mutableStateOf(CloudCampaignClient.getDefaultTemplateName(context)) }
    var cloudStatusMsg by remember { mutableStateOf("Pulsa 'Verificar Servidor Cloud' para comprobar elegibilidad.") }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val payload = BackupPayload(
                    ads = dao.getAllAdsList(),
                    groups = dao.getAllGroupsList(),
                    campaigns = dao.getAllCampaignsList(),
                    history = dao.getAllHistoryList()
                )
                val json = gson.toJson(payload)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "Respaldo JSON exportado correctamente", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (!json.isNullOrBlank()) {
                        val payload = gson.fromJson(json, BackupPayload::class.java)
                        if (payload.ads.isNotEmpty()) dao.insertAds(payload.ads)
                        if (payload.groups.isNotEmpty()) dao.insertGroups(payload.groups)
                        if (payload.campaigns.isNotEmpty()) dao.insertCampaigns(payload.campaigns)
                        if (payload.history.isNotEmpty()) dao.insertHistoryList(payload.history)
                        Toast.makeText(
                            context,
                            "Restaurados ${payload.ads.size} anuncios y ${payload.groups.size} destinos",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Error al importar JSON: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Configuración y Seguridad", fontWeight = FontWeight.Black, fontSize = 18.sp, color = WhiteText)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Conexión Segura al Servidor Cloud SHADOWHAT", fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                    Text(
                        "Las credenciales de WhatsApp Cloud API (WHATSAPP_CLOUD_API_TOKEN) se guardan únicamente en las variables de entorno del servidor, nunca en este APK.",
                        fontSize = 11.sp,
                        color = GraySubtext
                    )
                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = { serverUrl = it },
                        label = { Text("URL del Servidor Cloud (HTTPS)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = clientApiKey,
                        onValueChange = { clientApiKey = it },
                        label = { Text("Clave de Cliente (SHADOWHAT_API_KEY opcional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = defaultTemplate,
                        onValueChange = { defaultTemplate = it },
                        label = { Text("Nombre de Plantilla Cloud API por defecto") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(cloudStatusMsg, fontSize = 11.sp, color = Color(0xFF10B981))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                CloudCampaignClient.saveCloudConfig(context, serverUrl, clientApiKey, defaultTemplate)
                                coroutineScope.launch {
                                    val diag = CloudCampaignClient.checkDiagnostics(context)
                                    cloudStatusMsg = diag.summaryMessage
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Guardar y Verificar Servidor Cloud", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Detección de WhatsApp en el Dispositivo", fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                    Text(
                        text = when (availability) {
                            WhatsAppDispatcher.AppAvailability.WHATSAPP_BUSINESS -> "Instalado: WhatsApp Business (com.whatsapp.w4b)"
                            WhatsAppDispatcher.AppAvailability.WHATSAPP_STANDARD -> "Instalado: WhatsApp Estándar (com.whatsapp)"
                            WhatsAppDispatcher.AppAvailability.NONE -> "No se detectó WhatsApp instalado"
                        },
                        fontSize = 12.sp,
                        color = WhiteText
                    )
                    Button(
                        onClick = { WhatsAppDispatcher.openWhatsAppBusinessApp(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Abrir WhatsApp Business", fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            val powerDiag = remember { WhatsAppDispatcher.inspectBackgroundAndPowerState(context) }
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Segundo Plano, Doze, Fabricante (OEM) y Accesibilidad", fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                    Text(
                        text = "• Fabricante detectado: ${powerDiag.manufacturer}\n" +
                            "• Exento de optimización de batería (Doze): ${if (powerDiag.ignoringBatteryOptimizations) "SÍ ✅" else "NO (Recomendado activar)"}\n" +
                            "• Restricción en segundo plano activa: ${if (powerDiag.isBackgroundRestricted) "SÍ ⚠️" else "NO ✅"}",
                        fontSize = 11.sp,
                        color = WhiteText
                    )
                    Text(powerDiag.oemSpecificAdvice, fontSize = 11.sp, color = GoldAccent)
                    Text(powerDiag.accessibilityPolicyNote, fontSize = 10.sp, color = GraySubtext)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { WhatsAppDispatcher.openNotificationSettings(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Notificaciones", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { WhatsAppDispatcher.openBatteryOptimizationSettings(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Eximir de Batería / Doze", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Respaldo Local de Anuncios, Destinos e Historial (JSON)", fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { exportLauncher.launch("SHADOWHAT_Respaldo_v3.json") },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Exportar JSON", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Importar JSON", fontSize = 11.sp, color = WhiteText)
                        }
                    }
                }
            }
        }
    }
}
