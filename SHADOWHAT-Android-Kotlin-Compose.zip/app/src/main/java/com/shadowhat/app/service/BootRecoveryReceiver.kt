package com.shadowhat.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf

/**
 * Receptor del sistema Android para `BOOT_COMPLETED` y `MY_PACKAGE_REPLACED`.
 *
 * Cumple las restricciones de Android 12–14 (API 31–34):
 * En lugar de intentar iniciar un ForegroundService directamente desde el arranque del teléfono
 * (lo cual lanza ForegroundServiceStartNotAllowedException en Android 12+), encola un trabajo
 * único e idempotente en `WorkManager` (`CampaignWorker`) que recupera el estado desde Room DB
 * y sincroniza con el servidor Cloud sin duplicar mensajes.
 */
class BootRecoveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (
            action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val recoveryWork = OneTimeWorkRequestBuilder<CampaignWorker>()
                .setInputData(workDataOf("is_boot_recovery" to true))
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                "shadowhat_boot_recovery_work",
                ExistingWorkPolicy.KEEP,
                recoveryWork
            )
        }
    }
}
